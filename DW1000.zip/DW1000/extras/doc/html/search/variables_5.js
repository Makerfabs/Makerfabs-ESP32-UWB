var searchData=
[
  ['frame_5flength_5fextended',['FRAME_LENGTH_EXTENDED',['../classDW1000Class.html#ac08b428fc2e6d6eb92fbe731a337993c',1,'DW1000Class']]],
  ['frame_5flength_5fnormal',['FRAME_LENGTH_NORMAL',['../classDW1000Class.html#adeca7dcf1aba960907376fdd674663d0',1,'DW1000Class']]]
];
